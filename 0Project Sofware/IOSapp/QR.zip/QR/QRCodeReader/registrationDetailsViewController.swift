//
//  registrationDetailsViewController.swift
//  QRCodeReader
//
//  Created by Chaitanya Kiran Moturu on 06/12/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit
import Parse
class registrationDetailsViewController: UIViewController {
    var crn:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let query = PFQuery(className:"Courses")
        query.whereKey("CRN", equalTo: crn as Any)
        query.findObjectsInBackground {
            (objects, error) -> Void in
            if error == nil {
                // Looping through the objects to get the names of the workers in each object
                for object in objects! {
                    let course = object["CourseName"]
                    self.courseTxt.text = course as? String
                    let crn = object["CRN"]
                    self.crnText.text = crn as? String
                    let des = object["CourseDescription"]
                    self.courseTxtArea.text = des as? String
                    let pid = object["professorId"]
                    self.profId.text = pid as? String
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func alert(message: NSString, title: NSString) {
        let alert = UIAlertController(title: title as String, message: message as String, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBOutlet weak var crnText: UITextField!
    @IBOutlet weak var courseTxt: UITextField!
    @IBOutlet weak var courseTxtArea: UITextView!
    @IBOutlet weak var profId: UITextField!
    
    @IBAction func registerAction(_ sender: Any) {
        let object = PFObject(className: "regestries")
        let crn = crnText.text
        let user = PFUser.current()
        let sid =  user?["ID"]
            object["CRN"] = crn
            object["studentId"] = sid
            object["lacturesAttended"] = 0
            object.saveInBackground{
                (success, error) -> Void in
                if let error = error as NSError? {
                    let errorString = error.userInfo["error"] as? NSString
                    self.alert(message: errorString!, title: "Error")
                } else {
                    object.saveInBackground(block: { (d, NSError) in
                        if d {
                            let alert:UIAlertController = UIAlertController(title: "Success", message: "You are registred for this course", preferredStyle: .alert)
                            let defaultAction:UIAlertAction =  UIAlertAction(title: "OK", style: .cancel, handler: {action in self.navigationController?.popViewController(animated: true)})
                            alert.addAction(defaultAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                        else {
                            self.alert(message: "Some Thing went wrong on our side, Try Later", title: "Sorry!")
                        }
                    })
                }
            }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
