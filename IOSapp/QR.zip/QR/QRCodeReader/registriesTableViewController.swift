//
//  registriesTableViewController.swift
//  QRCodeReader
//
//  Created by Chaitanya Kiran Moturu on 06/12/17.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit
import Parse

class registriesTableViewController: UITableViewController {

    var titles:[String] = []
    var crns:[String] = []
    var regCrn:[String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titles = []
        crns = []
        regCrn=[]
        let user = PFUser.current()
        let sid =  user?["ID"]
        let reg = PFQuery(className:"regestries")
        reg.whereKey("studentId", equalTo:sid  as Any)
        reg.findObjectsInBackground {
            (objects, error) -> Void in
            if error == nil {
                // Looping through the objects to get the names of the workers in each object
                for object in objects! {
                    let crn = object["CRN"]
                    self.regCrn.append( crn as! String)
                }
                DispatchQueue.main.async(execute: { () -> Void in
                    let query = PFQuery(className:"Courses")
                    query.whereKey("regestrationsOpen", equalTo: "OPEN" as Any)
                    query.findObjectsInBackground {
                        (objects, error) -> Void in
                        if error == nil {
                            // Looping through the objects to get the names of the workers in each object
                            for object in objects! {
                                var flag = 0
                                let crn = object["CRN"] as! String
                                for crn1 in self.regCrn {
                                    if crn1 == crn{
                                        flag = 1
                                    }
                                }
                                if flag==0{
                                    var flag1 = 0
                                    for crn2 in self.crns {
                                        if crn2 == crn{
                                            flag1 = 1
                                        }
                                    }
                                    if(flag1 == 0){
                                        let subject = object["CourseName"]
                                        self.titles.append(subject as! String)
                                        self.crns.append( crn)
                                    }
                                }
                            }
                            DispatchQueue.main.async(execute: { () -> Void in
                                self.tableView.reloadData()
                            })
                        }
                    }
                })
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if titles.count > 0 {
            return titles.count
        }
        else {
            return 0
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "regCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = titles[indexPath.row]
        cell.detailTextLabel?.text = crns[indexPath.row]
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "regDetail", sender: Any?.self)
    }
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if let destination = segue.destination as? registrationDetailsViewController{
            destination.crn = crns[self.tableView.indexPathForSelectedRow!.row]
        }
    }
    

}
