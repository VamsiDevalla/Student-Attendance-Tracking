# Building a Barcode and QR code Reader in Swift

This is a demo app showing you how to implement QR and barcode scanning in Swift. For the full tutorial, please refer to the link below:

http://www.appcoda.com/barcode-reader-swift/
